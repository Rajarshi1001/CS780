# CS780 Assignment 2

Folder contains a single notebook named `CS780_Assn2_soln.ipynb` which containes the solutions and plots all algorithms and their comparisons respectively. 

> Run the cells sequentially in both the notebooks to generate the plots and execute the simulations. All the experiments are done with the `global seed set to 123` for making it reproducible. 

Directory Structure
```
200762_Assignment_2
|
|----CS780_Assignment1_Question.pdf
|----CS780_Assn2_soln.ipynb
|----README.md
```