# CS780 Assignment 1

Folder contains two notebooks named `CS780_Assn1_soln1.ipynb` and `CS780_Assn1_soln2.ipynb` files which containes the solutions and plots for Question 1 and 2 respectively. 

> Run the cells sequentially in both the notebooks to generate the plots and execute the simulations. All the experiments are done with the `global seed set to 123` for making it reproducible. 

Directory Structure
```
200762_Assignment_1
|
|----CS780_Assignment1_Question.pdf
|----CS780_Assn1_soln1.ipynb
|----CS780_Assn1_soln2.ipynb
|----README.md
```